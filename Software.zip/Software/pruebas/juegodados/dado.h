#ifndef DADO_H
#define DADO_H

class dado
{
public:
    dado();
    void lanzar();
    int getValorCara();
private:
    int valorCara;
};

#endif // DADO_H
