 #ifndef FUNCIONES_H
#define FUNCIONES_H

/**
  Genera todos los ficheros necesarios para el proyecto.
  */

void configuracion();
int generar_id();
void leer();



#endif // FUNCIONES_H
