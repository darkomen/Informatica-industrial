#ifndef SENSOR_H
#define SENSOR_H
#include <nodo.h>

class Sensor : public Nodo
{
public:
    Sensor();
    ~Sensor();

protected:
    // sensTyp _tipo;
};

#endif // SENSOR_H
