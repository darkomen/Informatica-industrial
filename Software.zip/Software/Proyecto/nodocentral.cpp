#include "nodocentral.h"
#include <iostream>
using namespace std;

NodoCentral::NodoCentral(){

}

void NodoCentral::addNodo(const Nodo n)
{
    _nodos.push_back(n);
}

void NodoCentral::showNodo()
{

}
