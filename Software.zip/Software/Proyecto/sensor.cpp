#include "sensor.h"
#include <iostream>
using namespace std;
Sensor::Sensor() : Nodo()
{
    // _tipo = tipo;
}
Sensor::~Sensor()
{
    cout << "Destructor de la clase Sensor" << endl;

}
