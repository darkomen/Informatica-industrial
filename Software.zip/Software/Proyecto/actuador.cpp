#include "actuador.h"
#include"funciones.h"
#include <iostream>
using namespace std;
Actuador::Actuador(): Nodo()
{

}
Actuador::~Actuador()
{
    cout << "Destructor de la clase Actuador" <<endl;
}
