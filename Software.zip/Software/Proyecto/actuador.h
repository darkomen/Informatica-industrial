#ifndef ACTUADOR_H
#define ACTUADOR_H
#include <nodo.h>

class Actuador: public Nodo
{
public:

    /** Constructor */
    Actuador();

    /** Destructor */
    ~Actuador();

    /** Métodos */
protected:
    /** Atributos */
    //actuTyp _tipo;
};

#endif // ACTUADOR_H
